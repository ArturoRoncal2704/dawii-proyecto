package org.cibertec.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "tb_transporte")
@Data
public class Transporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idTransporte;
   
    private String direccion;
    private Integer numeroPasajeros;
    @ManyToOne
    @JoinColumn(name = "idReserva")
    private Reserva reserva;
}
